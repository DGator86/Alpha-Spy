# Changelog

## 2.0.0 — 2026-08-06

- Unified research engine, live runtime, audit tape and Command Center GUI.
- Added one-command Ubuntu VPS installer.
- Added separate v2 databases to preserve prior system data.
- Added point-in-time constituent quote collection.
- Added rotating constituent IV/skew collection and SPY reference surface.
- Added immutable T+15 predictions and formal non-overlapping anchors.
- Added defined-risk strategy generator and deterministic maximum-loss checks.
- Added paper execution and guarded Tradier preview/reprice/cancel workflow.
- Added managed position monitor and broker-confirmed live exits.
- Added historical-data revision checks and counterfactual candidate scoring.
- Added daily 5:00 PM Eastern Google Drive backup.
- Added hardened systemd deployment and separate GUI tokens.
